import pytest


def test3():
    print("\n Test3!")
    assert True
