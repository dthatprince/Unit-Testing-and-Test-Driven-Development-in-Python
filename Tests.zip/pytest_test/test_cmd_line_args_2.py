import pytest


@pytest.mark.test3
def test2():
    print("\n Test2!")
    assert True
